#!/bin/sh
exec gcc -m32 "$@"
