#include "coders/coders-private.h"

#define MagickFTXTHeaders

#define MagickFTXTAliases

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

MagickCoderExports(FTXT)

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
